# Glue Streaming job: MSK IAM -> S3 Bronze/Silver + DynamoDB

This runbook is for Phase 11 after the MSK provisioned smoke test succeeds.

## Why this step

The EC2 producer/consumer smoke test proves MSK networking, IAM authentication,
and topic access.
The Glue streaming job proves the real processing path:

```text
Amazon MSK Provisioned with IAM auth
-> AWS Glue Spark Structured Streaming
-> S3 Bronze/Silver lake
-> DynamoDB current inventory state
-> Athena/Glue Catalog later
```

Validate Spark + MSK + S3 first with the DynamoDB sink disabled. After that,
enable DynamoDB as the cloud current-state sink.

## Files to deploy

Use the existing Spark job:

```text
spark/streaming_inventory_job.py
```

Package the project Python modules into a zip:

```bash
bash scripts/package_glue_streaming_job.sh
```

Upload both artifacts to S3:

```text
s3://<your-bucket>/glue/scripts/streaming_inventory_job.py
s3://<your-bucket>/glue/libs/inventory_streaming_libs.zip
```

Set the Glue job script path to:

```text
s3://<your-bucket>/glue/scripts/streaming_inventory_job.py
```

Then add the zip as an extra Python file:

```text
--extra-py-files s3://<your-bucket>/glue/libs/inventory_streaming_libs.zip
```

## Glue job configuration

Recommended first run:

```text
Glue version: 4.0 or newer
Type: Spark streaming
Worker type: G.1X
Number of workers: 2
```

Attach the Glue job to a Glue connection that has VPC/subnet/security group
access to the MSK provisioned brokers on port `9098`.

Because the current cluster exposes an IAM listener, Spark needs the Amazon MSK
IAM auth JAR in the Glue job classpath. Upload `aws-msk-iam-auth-*-all.jar` to
S3 and add it as an extra JAR.

## Job parameters

Example for MSK IAM:

```text
--bootstrap-servers <broker-1>:9098,<broker-2>:9098,<broker-3>:9098
--topic inventory-events
--auth-mode iam
--starting-offsets latest
--lake-root s3://<your-bucket>/warehouse-inventory/lake
--checkpoint-root s3://<your-bucket>/warehouse-inventory/checkpoints/glue-streaming
--enable-dynamodb-sink false
--extra-py-files s3://<your-bucket>/glue/libs/inventory_streaming_libs.zip
```

Use `latest` for a clean demo when you will produce fresh messages after the job
starts. Use `earliest` only when you intentionally want the job to consume old
topic data and the checkpoint path is new.

## DynamoDB current-state sink

Create these DynamoDB tables before enabling the sink:

```text
inventory_current_state        partition key: inventory_key
inventory_processed_events     partition key: event_id
inventory_alerts               partition key: alert_id
inventory_state_history        partition key: history_id
inventory_promotion_metrics    partition key: promotion_key
inventory_sales_velocity_5m    partition key: velocity_scope, sort key: window_start
```

The table names can be overridden with job environment variables:

```text
DDB_CURRENT_INVENTORY_TABLE
DDB_PROCESSED_EVENTS_TABLE
DDB_ALERTS_TABLE
DDB_STATE_HISTORY_TABLE
DDB_PROMOTION_METRICS_TABLE
DDB_SALES_VELOCITY_5M_TABLE
STATE_HISTORY_S3_PATH
```

By default, the current inventory state history is also written to:

```text
<LAKE_ROOT>/silver/current_inventory_state_history/
```

For this project bucket, that resolves to:

```text
s3://inventory-lake-fox/silver/current_inventory_state_history/
```

Seed the campaign state once before producing events:

```bash
export AWS_REGION=us-east-1
export CAMPAIGN_ID=CAMPAIGN_FLASH_0605

python3 scripts/seed_campaign_dynamodb.py
```

Then enable the sink in Glue:

```text
--enable-dynamodb-sink true
--enable-sales-velocity-dynamodb-sink true
```

The S3 `silver/sales_velocity_5m` path remains the historical analytics layer.
The DynamoDB `inventory_sales_velocity_5m` table is the realtime serving layer
for dashboards.

See `docs/cloud_runtime_config.md` for the split between fixed cloud config and
per-run runtime parameters.

## IAM permissions

The Glue job role needs:

- MSK IAM permissions for the cluster, topic, and consumer group
- S3 read/write permissions for the lake and checkpoint prefixes
- DynamoDB `DescribeTable`, `GetItem`, `PutItem`, `UpdateItem`, and `Query` on
  the current-state and sales-velocity tables when the DynamoDB sinks are enabled
- CloudWatch Logs permissions

Network access through VPC/subnet/security group is still required. Add inbound
TCP `9098` on the MSK security group from the Glue connection security group.

For a portfolio demo, scope the S3 policy to:

```text
s3://<your-bucket>/warehouse-inventory/*
```

## Validation

Start the Glue streaming job first, then run the real inventory producer against
MSK IAM.

Producer command:

```bash
export AWS_REGION=us-east-1
export MSK_AUTH_MODE=iam

bash scripts/run_cloud_producer.sh 20 1
```

Check S3 prefixes:

```text
s3://<your-bucket>/warehouse-inventory/lake/bronze/raw_inventory_events/
s3://<your-bucket>/warehouse-inventory/lake/silver/inventory_movements/
s3://<your-bucket>/warehouse-inventory/lake/silver/inventory_alerts/
s3://<your-bucket>/warehouse-inventory/lake/silver/sales_velocity_5m/
```

Stop the streaming job after validation to avoid unnecessary cost.

## Interview wording

I validated Amazon MSK IAM authentication first with a lightweight producer and
consumer. Then I moved the same topic into AWS Glue Spark Structured Streaming,
using the MSK IAM auth library on the JVM Kafka client and S3 streaming
checkpoints. After the Kafka-to-S3 path was stable, I enabled a DynamoDB
foreachBatch sink for idempotent current-inventory updates, processed-event
deduplication, alerts, state history, and promotion metrics.
